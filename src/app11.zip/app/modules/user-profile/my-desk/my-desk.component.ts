import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-desk',
  templateUrl: './my-desk.component.html',
  styleUrls: ['./my-desk.component.css']
})
export class MyDeskComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
