import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-reading',
  templateUrl: './my-reading.component.html',
  styleUrls: ['./my-reading.component.css']
})
export class MyReadingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
