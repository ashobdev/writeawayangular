import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-my-submissions",
  templateUrl: "./my-submissions.component.html",
  styleUrls: ["./my-submissions.component.css"],
})
export class MySubmissionsComponent implements OnInit {
  count: number = 0;
  constructor() {}

  ngOnInit() {}
}
