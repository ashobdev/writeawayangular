<html>
<head>
  <link rel="stylesheet" type="text/css" href="ct.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="https://fonts.googleapis.com/css?family=Roboto:400,500|Open+Sans" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
  
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script>
    $(document).ready(function () {
      $('[data-toggle="tooltip"]').tooltip();
    });
  </script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  <script src="./pagination.js"></script>
  <script src="https://www.gstatic.com/firebasejs/4.8.1/firebase.js"></script>
  <script src="index.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>

<body class=" login-background">
  <div class="container dashboard-background">
    <div class="container">
      <div class="row">
        <div class="col-md-3 center">
          <img src="assets/cityHUNT-logo-2020.svg" class="login-logo dashboard-logo">
          <a class="game-link" href="game-title.htm"> <p class="createGame-input">CREATE NEW GAME </p></a>
          <input type="text" placeholder="search" class="gameCreate-input"><br><br>
		  <button onclick="logout()">Logout</button>
        </div>
        <div class="col-md-9">
          <span class="header-game">GAMES</span>
          <table class="table table-bordered game-table create-game-table">
           
              <tr>
                <th>Game Name</th>
                <th>Date</th>
                <th>Tags</th>
                <th>Updated</th>
                <th>Game Code</th>
              </tr>

              <tbody id="myTable">
              <tr>
                <td>
                    <div id="accordion" class="custom-accordion">
                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapseOne">
                          <a class="card-title1">Addison Group Classic</a>
                      </div>
                    </div>
                </td>
                <td>3.08.20</td>
                <td>Unlock, Birthday</td>
                <td>hour ago</td>
                <td>Game Code</td>

              </tr>
              <tr>
                 <td colspan="12" class="custom-column">
                  <div id="collapseOne" class="collapse" data-parent="#accordion">
                    <div class="game-btns">
                     <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                     <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone Game</button></a>
                     <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                     <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                     <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                    </div>
                  </div>
                  </td>
                </tr>
             
                <tr>
                  <td>
                      <div id="accordion" class="custom-accordion">
                          <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapsetwo">
                            <a class="card-title1">Addison Group Classic</a>
                        </div>
                      </div>
                  </td>
                  <td>3.08.20</td>
                  <td>Unlock, Birthday</td>
                  <td>hour ago</td>
                  <td>Game Code</td>
  
                </tr>
                <tr>
                   <td colspan="12" class="custom-column">
                    <div id="collapsetwo" class="collapse" data-parent="#accordion">
                      <div class="game-btns">
                        <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                        <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone Game</button></a>
                        <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                        <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                        <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                       </div>
                    </div>
                    </td>
                  </tr>




                  <tr>
                    <td>
                        <div id="accordion" class="custom-accordion">
                            <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapsethree">
                              <a class="card-title1">Addison Group Classic</a>
                          </div>
                        </div>
                    </td>
                    <td>3.08.20</td>
                    <td>Unlock, Birthday</td>
                    <td>hour ago</td>
                    <td>Game Code</td>
    
                  </tr>
                  <tr>
                     <td colspan="12" class="custom-column">
                      <div id="collapsethree" class="collapse" data-parent="#accordion">
                        <div class="game-btns">
                          <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                          <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone Game</button></a>
                          <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                          <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                          <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                         </div>
                      </div>
                      </td>
                    </tr>




                    <tr>
                      <td>
                          <div id="accordion" class="custom-accordion">
                              <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapsefour">
                                <a class="card-title1">Addison Group Classic</a>
                            </div>
                          </div>
                      </td>
                      <td>3.08.20</td>
                      <td>Unlock, Birthday</td>
                      <td>hour ago</td>
                      <td>Game Code</td>
      
                    </tr>
                    <tr>
                       <td colspan="12" class="custom-column">
                        <div id="collapsefour" class="collapse" data-parent="#accordion">
                          <div class="game-btns">
                            <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                            <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone Game</button></a>
                            <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                            <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                            <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                           </div>
                        </td>
                      </tr>


                      <tr>
                        <td>
                            <div id="accordion" class="custom-accordion">
                                <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapsefive">
                                  <a class="card-title1">Addison Group Classic</a>
                              </div>
                            </div>
                        </td>
                        <td>3.08.20</td>
                        <td>Unlock, Birthday</td>
                        <td>hour ago</td>
                        <td>Game Code</td>
        
                      </tr>
                      <tr>
                         <td colspan="12" class="custom-column">
                          <div id="collapsefive" class="collapse" data-parent="#accordion">
                            <div class="game-btns">
                              <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                              <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone Game</button></a>
                              <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                              <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                              <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                             </div>
                          </div>
                          </td>
                        </tr>


                        <tr>
                          <td>
                              <div id="accordion" class="custom-accordion">
                                  <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapsesix">
                                    <a class="card-title1">Addison Group Classic</a>
                                </div>
                              </div>
                          </td>
                          <td>3.08.20</td>
                          <td>Unlock, Birthday</td>
                          <td>hour ago</td>
                          <td>Game Code</td>
          
                        </tr>
                        <tr>
                           <td colspan="12" class="custom-column">
                            <div id="collapsesix" class="collapse" data-parent="#accordion">
                              <div class="game-btns">
                                <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone Game</button></a>
                                <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                               </div>
                            </div>
                            </td>
                          </tr>

                          
                          <tr>
                            <td>
                                <div id="accordion" class="custom-accordion">
                                    <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapseseven">
                                      <a class="card-title1">Addison Group Classic</a>
                                  </div>
                                </div>
                            </td>
                            <td>3.08.20</td>
                            <td>Unlock, Birthday</td>
                            <td>hour ago</td>
                            <td>Game Code</td>
            
                          </tr>
                          <tr>
                             <td colspan="12" class="custom-column">
                              <div id="collapseseven" class="collapse" data-parent="#accordion">
                                <div class="game-btns">
                                  <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                  <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone Game</button></a>
                                  <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                  <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                  <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                 </div>
                              </div>
                              </td>
                            </tr>


                            <tr>
                              <td>
                                  <div id="accordion" class="custom-accordion">
                                      <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapseeight">
                                        <a class="card-title1">Addison Group Classic</a>
                                    </div>
                                  </div>
                              </td>
                              <td>3.08.20</td>
                              <td>Unlock, Birthday</td>
                              <td>hour ago</td>
                              <td>Game Code</td>
              
                            </tr>
                            <tr>
                               <td colspan="12" class="custom-column">
                                <div id="collapseeight" class="collapse" data-parent="#accordion">
                                  <div class="game-btns">
                                    <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                    <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone Game</button></a>
                                    <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                    <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                    <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                   </div>
                                </div>
                                </td>
                              </tr>

                              <tr>
                                <td>
                                    <div id="accordion" class="custom-accordion">
                                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapsenine">
                                          <a class="card-title1">Addison Group Classic</a>
                                      </div>
                                    </div>
                                </td>
                                <td>3.08.20</td>
                                <td>Unlock, Birthday</td>
                                <td>hour ago</td>
                                <td>Game Code</td>
                
                              </tr>
                              <tr>
                                 <td colspan="12" class="custom-column">
                                  <div id="collapsenine" class="collapse" data-parent="#accordion">
                                    <div class="game-btns">
                                      <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                      <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone Game</button></a>
                                      <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                      <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                      <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                     </div>
                                  </div>
                                  </td>
                                </tr>

                                <tr>
                                  <td>
                                      <div id="accordion" class="custom-accordion">
                                          <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapseten">
                                            <a class="card-title1">Addison Group Classic</a>
                                        </div>
                                      </div>
                                  </td>
                                  <td>3.08.20</td>
                                  <td>Unlock, Birthday</td>
                                  <td>hour ago</td>
                                  <td>Game Code</td>
                  
                                </tr>
                                <tr>
                                   <td colspan="12" class="custom-column">
                                    <div id="collapseten" class="collapse" data-parent="#accordion">
                                      <div class="game-btns">
                                        <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                        <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone Game</button></a>
                                        <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                        <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                        <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                       </div> 
                                    </div>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>
                                      <div id="accordion" class="custom-accordion">
                                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapsetengame-title-search">
                                          <a class="card-title1">Addison Group Classic</a>
                                        </div>
                                      </div>
                                    </td>
                                    <td>3.08.20</td>
                                    <td>Unlock, Birthday</td>
                                    <td>hour ago</td>
                                    <td>Game Code</td>
                                  
                                  </tr>
                                  <tr>
                                    <td colspan="12" class="custom-column">
                                      <div id="collapseten" class="collapse" data-parent="#accordion">
                                        <div class="game-btns">
                                          <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                          <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone
                                              Game</button></a>
                                          <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                          <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                          <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>
                                      <div id="accordion" class="custom-accordion">
                                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapse11">
                                          <a class="card-title1">Addison Group Classic</a>
                                        </div>
                                      </div>
                                    </td>
                                    <td>3.08.20</td>
                                    <td>Unlock, Birthday</td>
                                    <td>hour ago</td>
                                    <td>Game Code</td>
                                  
                                  </tr>
                                  <tr>
                                    <td colspan="12" class="custom-column">
                                      <div id="collapse11" class="collapse" data-parent="#accordion">
                                        <div class="game-btns">
                                          <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                          <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone
                                              Game</button></a>
                                          <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                          <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                          <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>
                                      <div id="accordion" class="custom-accordion">
                                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapse12">
                                          <a class="card-title1">Addison Group Classic</a>
                                        </div>
                                      </div>
                                    </td>
                                    <td>3.08.20</td>
                                    <td>Unlock, Birthday</td>
                                    <td>hour ago</td>
                                    <td>Game Code</td>
                                  
                                  </tr>
                                  <tr>
                                    <td colspan="12" class="custom-column">
                                      <div id="collapse12" class="collapse" data-parent="#accordion">
                                        <div class="game-btns">
                                          <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                          <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone
                                              Game</button></a>
                                          <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                          <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                          <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>
                                      <div id="accordion" class="custom-accordion">
                                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapse13">
                                          <a class="card-title1">Addison Group Classic</a>
                                        </div>
                                      </div>
                                    </td>
                                    <td>3.08.20</td>
                                    <td>Unlock, Birthday</td>
                                    <td>hour ago</td>
                                    <td>Game Code</td>
                                  
                                  </tr>
                                  <tr>
                                    <td colspan="12" class="custom-column">
                                      <div id="collapse13" class="collapse" data-parent="#accordion">
                                        <div class="game-btns">
                                          <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                          <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone
                                              Game</button></a>
                                          <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                          <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                          <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>
                                      <div id="accordion" class="custom-accordion">
                                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapse14">
                                          <a class="card-title1">Addison Group Classic</a>
                                        </div>
                                      </div>
                                    </td>
                                    <td>3.08.20</td>
                                    <td>Unlock, Birthday</td>
                                    <td>hour ago</td>
                                    <td>Game Code</td>
                                  
                                  </tr>
                                  <tr>
                                    <td colspan="12" class="custom-column">
                                      <div id="collapse14" class="collapse" data-parent="#accordion">
                                        <div class="game-btns">
                                          <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                          <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone
                                              Game</button></a>
                                          <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                          <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                          <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>
                                      <div id="accordion" class="custom-accordion">
                                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapse15">
                                          <a class="card-title1">Addison Group Classic</a>
                                        </div>
                                      </div>
                                    </td>
                                    <td>3.08.20</td>
                                    <td>Unlock, Birthday</td>
                                    <td>hour ago</td>
                                    <td>Game Code</td>
                                  
                                  </tr>
                                  <tr>
                                    <td colspan="12" class="custom-column">
                                      <div id="collapse15" class="collapse" data-parent="#accordion">
                                        <div class="game-btns">
                                          <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                          <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone
                                              Game</button></a>
                                          <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                          <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                          <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>
                                      <div id="accordion" class="custom-accordion">
                                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapse16">
                                          <a class="card-title1">Addison Group Classic</a>
                                        </div>
                                      </div>
                                    </td>
                                    <td>3.08.20</td>
                                    <td>Unlock, Birthday</td>
                                    <td>hour ago</td>
                                    <td>Game Code</td>
                                  
                                  </tr>
                                  <tr>
                                    <td colspan="12" class="custom-column">
                                      <div id="collapse16" class="collapse" data-parent="#accordion">
                                        <div class="game-btns">
                                          <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                          <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone
                                              Game</button></a>
                                          <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                          <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                          <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>
                                      <div id="accordion" class="custom-accordion">
                                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapse17">
                                          <a class="card-title1">Addison Group Classic</a>
                                        </div>
                                      </div>
                                    </td>
                                    <td>3.08.20</td>
                                    <td>Unlock, Birthday</td>
                                    <td>hour ago</td>
                                    <td>Game Code</td>
                                  
                                  </tr>
                                  <tr>
                                    <td colspan="12" class="custom-column">
                                      <div id="collapse17" class="collapse" data-parent="#accordion">
                                        <div class="game-btns">
                                          <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                          <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone
                                              Game</button></a>
                                          <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                          <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                          <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>
                                      <div id="accordion" class="custom-accordion">
                                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapse18">
                                          <a class="card-title1">Addison Group Classic</a>
                                        </div>
                                      </div>
                                    </td>
                                    <td>3.08.20</td>
                                    <td>Unlock, Birthday</td>
                                    <td>hour ago</td>
                                    <td>Game Code</td>
                                  
                                  </tr>
                                  <tr>
                                    <td colspan="12" class="custom-column">
                                      <div id="collapse18" class="collapse" data-parent="#accordion">
                                        <div class="game-btns">
                                          <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                          <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone
                                              Game</button></a>
                                          <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                          <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                          <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>
                                      <div id="accordion" class="custom-accordion">
                                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapse19">
                                          <a class="card-title1">Addison Group Classic</a>
                                        </div>
                                      </div>
                                    </td>
                                    <td>3.08.20</td>
                                    <td>Unlock, Birthday</td>
                                    <td>hour ago</td>
                                    <td>Game Code</td>
                                  
                                  </tr>
                                  <tr>
                                    <td colspan="12" class="custom-column">
                                      <div id="collapse19" class="collapse" data-parent="#accordion">
                                        <div class="game-btns">
                                          <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                          <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone
                                              Game</button></a>
                                          <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                          <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                          <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>
                                      <div id="accordion" class="custom-accordion">
                                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapse20">
                                          <a class="card-title1">Addison Group Classic</a>
                                        </div>
                                      </div>
                                    </td>
                                    <td>3.08.20</td>
                                    <td>Unlock, Birthday</td>
                                    <td>hour ago</td>
                                    <td>Game Code</td>
                                  
                                  </tr>
                                  <tr>
                                    <td colspan="12" class="custom-column">
                                      <div id="collapse20" class="collapse" data-parent="#accordion">
                                        <div class="game-btns">
                                          <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                          <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone
                                              Game</button></a>
                                          <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                          <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                          <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>
                                      <div id="accordion" class="custom-accordion">
                                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapse21">
                                          <a class="card-title1">Addison Group Classic</a>
                                        </div>
                                      </div>
                                    </td>
                                    <td>3.08.20</td>
                                    <td>Unlock, Birthday</td>
                                    <td>hour ago</td>
                                    <td>Game Code</td>
                                  
                                  </tr>
                                  <tr>
                                    <td colspan="12" class="custom-column">
                                      <div id="collapse21" class="collapse" data-parent="#accordion">
                                        <div class="game-btns">
                                          <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                          <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone
                                              Game</button></a>
                                          <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                          <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                          <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>
                                      <div id="accordion" class="custom-accordion">
                                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapse23">
                                          <a class="card-title1">Addison Group Classic</a>
                                        </div>
                                      </div>
                                    </td>
                                    <td>3.08.20</td>
                                    <td>Unlock, Birthday</td>
                                    <td>hour ago</td>
                                    <td>Game Code</td>
                                  
                                  </tr>
                                  <tr>
                                    <td colspan="12" class="custom-column">
                                      <div id="collapse23" class="collapse" data-parent="#accordion">
                                        <div class="game-btns">
                                          <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                          <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone
                                              Game</button></a>
                                          <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                          <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                          <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>
                                      <div id="accordion" class="custom-accordion">
                                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapse24">
                                          <a class="card-title1">Addison Group Classic</a>
                                        </div>
                                      </div>
                                    </td>
                                    <td>3.08.20</td>
                                    <td>Unlock, Birthday</td>
                                    <td>hour ago</td>
                                    <td>Game Code</td>
                                  
                                  </tr>
                                  <tr>
                                    <td colspan="12" class="custom-column">
                                      <div id="collapse24" class="collapse" data-parent="#accordion">
                                        <div class="game-btns">
                                          <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                          <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone
                                              Game</button></a>
                                          <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                          <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                          <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>
                                      <div id="accordion" class="custom-accordion">
                                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapse25">
                                          <a class="card-title1">Addison Group Classic</a>
                                        </div>
                                      </div>
                                    </td>
                                    <td>3.08.20</td>
                                    <td>Unlock, Birthday</td>
                                    <td>hour ago</td>
                                    <td>Game Code</td>
                                  
                                  </tr>
                                  <tr>
                                    <td colspan="12" class="custom-column">
                                      <div id="collapse25" class="collapse" data-parent="#accordion">
                                        <div class="game-btns">
                                          <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                          <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone
                                              Game</button></a>
                                          <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                          <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                          <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>
                                      <div id="accordion" class="custom-accordion">
                                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapse26">
                                          <a class="card-title1">Addison Group Classic</a>
                                        </div>
                                      </div>
                                    </td>
                                    <td>3.08.20</td>
                                    <td>Unlock, Birthday</td>
                                    <td>hour ago</td>
                                    <td>Game Code</td>
                                  
                                  </tr>
                                  <tr>
                                    <td colspan="12" class="custom-column">
                                      <div id="collapse26" class="collapse" data-parent="#accordion">
                                        <div class="game-btns">
                                          <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                          <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone
                                              Game</button></a>
                                          <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                          <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                          <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>
                                      <div id="accordion" class="custom-accordion">
                                        <div class="custom-card-header collapsed" data-toggle="collapse" href="#collapse27">
                                          <a class="card-title1">Addison Group Classic</a>
                                        </div>
                                      </div>
                                    </td>
                                    <td>3.08.20</td>
                                    <td>Unlock, Birthday</td>
                                    <td>hour ago</td>
                                    <td>Game Code</td>
                                  
                                  </tr>
                                  <tr>
                                    <td colspan="12" class="custom-column">
                                      <div id="collapse27" class="collapse" data-parent="#accordion">
                                        <div class="game-btns">
                                          <a href="game-title.htm"> <button class="game-btn-name">Edit Game</button></a>
                                          <a href="#" data-toggle="tooltip" title="This will create a new game."> <button class="game-btn-name">Clone
                                              Game</button></a>
                                          <a href="teams.html"> <button class="game-btn-name">Team</button></a>
                                          <a href="stream.html"> <button class="game-btn-name">Stream</button></a>
                                          <a href="monitor.html"> <button class="game-btn-name">Monitor</button></a>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>


                        </tbody>
                        </table>

                        <div class="col-md-12 text-center">
                          <ul class="pagination pagination-lg pager" id="myPager"></ul>
                        </div>
        </div>
      </div>
    </div>
  </div>
</body>

</html>