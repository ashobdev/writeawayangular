var loc = window.location.pathname;
var dir = loc.substring(0, loc.lastIndexOf('/'));
var project_path = window.location.origin + dir + '/';
// Initialize Firebase
var config = {apiKey: "AIzaSyBcO09ING8RF7BnC9aXjPue1vJfZkwl_os",authDomain: "cityhuntdevelop.firebaseapp.com",databaseURL: "https://cityhuntdevelop.firebaseio.com",storageBucket: "cityhuntdevelop.appspot.com"};
firebase.initializeApp(config);

//Authentication of users
firebase.auth().onAuthStateChanged(function(user) {
  if (user){
	// User is signed in.
	//document.getElementById("create-acc").style.display = "none";
  }
});

function login(){

  var userEmail = document.getElementById("email_field").value;
  var userPass = document.getElementById("password_field").value;

  firebase.auth().signInWithEmailAndPassword(userEmail, userPass).catch(function(error) {
    // Handle Errors here.
    var errorCode = error.code;
    var errorMessage = error.message;

    window.alert("Error : "+ errorCode + errorMessage);
	return false;
  });
  firebase.auth().onAuthStateChanged(function(user) {
	  if (user){
		// User is signed in.
		window.location.href = project_path+"dashboard.php";
	  }
  });
}

function emailIsValid (email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

function signup(){
  
	var userName = document.getElementById("name_field").value;
	var userEmail = document.getElementById("email_field").value;
	var userPass = document.getElementById("password_field").value;
	var userRePass = document.getElementById("re_type_password_field").value;
	if(userName == '')
	{
		window.alert("Required Name");
		return false;
	}
	if(userEmail != '')
	{  
		if(emailIsValid(userEmail) == false){
			alert('not valide');
		}
	}else{
		window.alert("Required email");
		return false;
	}
	
	if(userPass == ''){
		window.alert("Required password");
		return false;
	}
	if(userRePass == ''){
		window.alert("Required confirm password");
		return false;
	}
	
	if(userPass != '' && userRePass != ''){
		if(userPass == userRePass){
			//Create User with Email and Password
			firebase.auth().createUserWithEmailAndPassword(userEmail, userPass).then(function(user){
				// var user = firebase.auth().currentUser;
				user.updateProfile({
					displayName: userName
				}).then(function() {
					// Update successful.
				}, function(error) {
					// An error happened.
				});     
				window.location.href = project_path+"index.html";				
			}, function(error){
				// Handle Errors here.
				var errorCode = error.code;
				var errorMessage = error.message;
				if (errorCode == 'auth/weak-password') {
					alert('The password is too weak.');
				} else {
					console.error(error);
				}
				//window.alert("Error : " + errorMessage);
			});
		}else{
			alert("Confirm Password not matched"); 
			return false;
		}
	}
}

function logout(){
	firebase.auth().signOut()
	.then(function() {
	  // Sign-out successful.
	  window.location.href = project_path+"index.html";
	  console.log('User Logged Out!');
	}).catch(function(error) {
	  // An error happened.
	  console.log(error);
	});	
   //firebase.auth().signOut();
}

var database = firebase.database();
